export interface StudyFile {
  id: string;
  name: string;
  content: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  createdAt: Date;
  sections: Section[];
  progress: number;
  totalStudyTime: number;
  lastStudied?: Date;
  downloadUrl?: string;
  tags: string[];
}

export interface Section {
  id: string;
  title: string;
  content: string;
  summary: string;
  keyPoints: string[];
  explanation: string;
  quiz: QuizQuestion[];
  flashcards: Flashcard[];
  isStudied: boolean;
  notes: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  mastered: boolean;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  duration: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  playlist?: string;
  views: number;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: Date;
  time: string;
  type: 'lecture' | 'exam' | 'deadline' | 'session';
  link?: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  helpful: number;
}

export interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export type ViewMode = 'home' | 'files' | 'study' | 'quiz' | 'flashcards' | 'videos' | 'calendar' | 'faq' | 'ai' | 'stats' | 'pomodoro' | 'search' | 'support';
