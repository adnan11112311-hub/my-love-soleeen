import { useState, useEffect, useMemo, useRef } from 'react';
import { StudyFile, Video, Event, FAQ, Message, ViewMode } from './types';
import { processFileContent, generateAIResponse } from './utils/aiProcessor';
import { saveFiles, loadFiles as loadFilesFromDB } from './utils/storage';
import pdfToText from 'react-pdftotext';

// ============ ICONS ============
const Icons = {
  Home: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>,
  Folder: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>,
  Book: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>,
  Quiz: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>,
  Video: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>,
  Calendar: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Help: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  AI: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
  Chart: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>,
  Clock: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  Search: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>,
  Plus: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>,
  Upload: () => <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>,
  X: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>,
  Check: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>,
  Trash: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
  Cards: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>,
  Send: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>,
  Arrow: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>,
  ArrowLeft: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>,
  Play: () => <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>,
  Download: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>,
  ExternalLink: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>,
  Menu: () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>,
  Support: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  ThumbUp: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" /></svg>,
};

// ============ CONSTANTS ============
const categories = [
  { id: 'all', name: 'الكل', icon: '📚', color: 'from-slate-500 to-slate-600' },
  { id: 'math', name: 'رياضيات', icon: '📐', color: 'from-blue-500 to-blue-600' },
  { id: 'physics', name: 'فيزياء', icon: '⚛️', color: 'from-purple-500 to-purple-600' },
  { id: 'chemistry', name: 'كيمياء', icon: '🧪', color: 'from-green-500 to-green-600' },
  { id: 'biology', name: 'أحياء', icon: '🧬', color: 'from-emerald-500 to-emerald-600' },
  { id: 'programming', name: 'برمجة', icon: '💻', color: 'from-violet-500 to-violet-600' },
  { id: 'language', name: 'لغات', icon: '📝', color: 'from-yellow-500 to-yellow-600' },
  { id: 'other', name: 'أخرى', icon: '📁', color: 'from-gray-500 to-gray-600' },
];

const levels = [
  { id: 'beginner', name: 'مبتدئ', color: 'level-beginner', icon: '🌱' },
  { id: 'intermediate', name: 'متوسط', color: 'level-intermediate', icon: '🌿' },
  { id: 'advanced', name: 'متقدم', color: 'level-advanced', icon: '🌳' },
];

const socialLinks = [
  { name: 'تليجرام', icon: '📱', url: 'https://t.me/studyai', color: 'from-blue-400 to-blue-600' },
  { name: 'واتساب', icon: '💬', url: 'https://wa.me/1234567890', color: 'from-green-400 to-green-600' },
  { name: 'يوتيوب', icon: '▶️', url: 'https://youtube.com', color: 'from-red-400 to-red-600' },
];

// ============ SAMPLE DATA ============
const sampleVideos: Video[] = [
  { id: '1', title: 'مقدمة في الفيزياء', description: 'شرح أساسيات الفيزياء للمبتدئين', thumbnail: 'https://picsum.photos/seed/physics/400/225', url: 'https://youtube.com', duration: '15:30', category: 'physics', level: 'beginner', playlist: 'أساسيات الفيزياء', views: 1250 },
  { id: '2', title: 'قوانين نيوتن', description: 'شرح مفصل لقوانين نيوتن الثلاثة', thumbnail: 'https://picsum.photos/seed/newton/400/225', url: 'https://youtube.com', duration: '22:45', category: 'physics', level: 'beginner', playlist: 'أساسيات الفيزياء', views: 890 },
  { id: '3', title: 'البرمجة بـ Python', description: 'تعلم أساسيات البرمجة', thumbnail: 'https://picsum.photos/seed/python/400/225', url: 'https://youtube.com', duration: '45:00', category: 'programming', level: 'beginner', playlist: 'Python للمبتدئين', views: 3200 },
  { id: '4', title: 'التفاضل والتكامل', description: 'شرح متقدم في الرياضيات', thumbnail: 'https://picsum.photos/seed/calculus/400/225', url: 'https://youtube.com', duration: '35:20', category: 'math', level: 'advanced', playlist: 'رياضيات متقدمة', views: 567 },
];

const sampleEvents: Event[] = [
  { id: '1', title: 'محاضرة الفيزياء', description: 'مراجعة شاملة للوحدة الثانية', date: new Date(Date.now() + 86400000 * 2), time: '18:00', type: 'lecture', link: 'https://zoom.us' },
  { id: '2', title: 'اختبار الرياضيات', description: 'الاختبار النصفي', date: new Date(Date.now() + 86400000 * 5), time: '10:00', type: 'exam' },
  { id: '3', title: 'تسليم المشروع', description: 'آخر موعد لتسليم مشروع البرمجة', date: new Date(Date.now() + 86400000 * 7), time: '23:59', type: 'deadline' },
];

const sampleFAQs: FAQ[] = [
  { id: '1', question: 'كيف أرفع ملفاتي الدراسية؟', answer: 'اذهب لقسم "ملفاتي" واضغط على "إضافة ملف"، يمكنك رفع PDF أو TXT أو لصق النص مباشرة.', category: 'general', helpful: 45 },
  { id: '2', question: 'هل يمكنني تحميل الملفات؟', answer: 'نعم، كل ملف يمكن تحميله بصيغة PDF أو نسخ محتواه.', category: 'files', helpful: 32 },
  { id: '3', question: 'كيف تعمل الاختبارات؟', answer: 'يتم إنشاء أسئلة تلقائياً من محتوى ملفاتك باستخدام الذكاء الاصطناعي.', category: 'quiz', helpful: 28 },
  { id: '4', question: 'ما هي تقنية بومودورو؟', answer: 'تقنية لإدارة الوقت: 25 دقيقة دراسة ثم 5 دقائق راحة.', category: 'study', helpful: 56 },
  { id: '5', question: 'كيف أتواصل مع الدعم؟', answer: 'يمكنك التواصل عبر التليجرام أو الواتساب من قسم "الدعم الفني".', category: 'support', helpful: 21 },
];

// ============ MAIN APP ============
export default function App() {
  const [view, setView] = useState<ViewMode>('home');
  const [files, setFiles] = useState<StudyFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<StudyFile | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [storageInfo, setStorageInfo] = useState({ used: 0, total: 0 });
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('arena_darkMode');
    return saved !== 'false'; // Default to dark mode
  });
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Theme effect
  useEffect(() => {
    document.body.classList.toggle('light-mode', !darkMode);
    localStorage.setItem('arena_darkMode', String(darkMode));
  }, [darkMode]);

  // Scroll to top visibility
  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 300);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Load files from IndexedDB on mount
  useEffect(() => {
    loadFilesFromDB().then(loadedFiles => {
      setFiles(loadedFiles);
      setIsLoading(false);
    }).catch(() => setIsLoading(false));
  }, []);

  // Save files to IndexedDB when changed
  useEffect(() => {
    if (!isLoading && files.length >= 0) {
      saveFiles(files);
      // Update storage info
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        navigator.storage.estimate().then(estimate => {
          setStorageInfo({
            used: Math.round((estimate.usage || 0) / 1024 / 1024),
            total: Math.round((estimate.quota || 0) / 1024 / 1024),
          });
        });
      }
    }
  }, [files, isLoading]);

  const stats = useMemo(() => ({
    totalFiles: files.length,
    totalSections: files.reduce((a, f) => a + f.sections.length, 0),
    completedSections: files.reduce((a, f) => a + f.sections.filter(s => s.isStudied).length, 0),
    totalQuizzes: files.reduce((a, f) => a + f.sections.reduce((b, s) => b + s.quiz.length, 0), 0),
    totalTime: files.reduce((a, f) => a + f.totalStudyTime, 0),
  }), [files]);

  const completionRate = stats.totalSections > 0 ? Math.round((stats.completedSections / stats.totalSections) * 100) : 0;

  // Search functionality
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return { files: [], videos: [], faqs: [] };
    const q = searchQuery.toLowerCase();
    return {
      files: files.filter(f => f.name.toLowerCase().includes(q) || f.content.toLowerCase().includes(q)),
      videos: sampleVideos.filter(v => v.title.toLowerCase().includes(q) || v.description.toLowerCase().includes(q)),
      faqs: sampleFAQs.filter(f => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q)),
    };
  }, [searchQuery, files]);

  const menuItems = [
    { id: 'home' as ViewMode, icon: <Icons.Home />, label: 'الرئيسية' },
    { id: 'files' as ViewMode, icon: <Icons.Folder />, label: 'ملفاتي', badge: files.length },
    { id: 'study' as ViewMode, icon: <Icons.Book />, label: 'الدراسة' },
    { id: 'quiz' as ViewMode, icon: <Icons.Quiz />, label: 'الاختبارات' },
    { id: 'flashcards' as ViewMode, icon: <Icons.Cards />, label: 'البطاقات' },
    { id: 'videos' as ViewMode, icon: <Icons.Video />, label: 'الفيديوهات' },
    { id: 'calendar' as ViewMode, icon: <Icons.Calendar />, label: 'الجدول' },
    { id: 'faq' as ViewMode, icon: <Icons.Help />, label: 'الأسئلة الشائعة' },
    { id: 'ai' as ViewMode, icon: <Icons.AI />, label: 'مساعد AI' },
    { id: 'pomodoro' as ViewMode, icon: <Icons.Clock />, label: 'بومودورو' },
    { id: 'stats' as ViewMode, icon: <Icons.Chart />, label: 'الإحصائيات' },
    { id: 'support' as ViewMode, icon: <Icons.Support />, label: 'الدعم' },
  ];

  return (
    <div className="min-h-screen" dir="rtl">
      {/* SIDEBAR - Desktop */}
      <aside className="fixed right-0 top-0 h-full w-64 glass border-l border-white/5 z-40 hidden lg:flex flex-col">
        <div className="p-5 border-b border-white/5">
          <h1 className="text-2xl font-bold gradient-text">Arena</h1>
          <p className="text-xs text-zinc-500 mt-1">منصة الدراسة الذكية</p>
        </div>

        {/* Search */}
        <div className="p-3">
          <button
            onClick={() => setShowSearch(true)}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl bg-white/5 text-zinc-400 hover:bg-white/10 transition-all"
          >
            <Icons.Search />
            <span className="text-sm">بحث...</span>
            <span className="mr-auto text-xs bg-white/10 px-2 py-0.5 rounded">⌘K</span>
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => { setView(item.id); setShowMobileMenu(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                view === item.id 
                  ? 'bg-gradient-to-l from-violet-600/20 to-transparent text-white border-r-2 border-violet-500' 
                  : 'text-zinc-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {item.icon}
              <span className="flex-1 text-right text-sm">{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="badge">{item.badge}</span>
              )}
            </button>
          ))}
        </nav>

        {/* Progress */}
        <div className="p-4 border-t border-white/5">
          <div className="glass rounded-xl p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-zinc-500">التقدم الكلي</span>
              <span className="text-xs text-violet-400 font-bold">{completionRate}%</span>
            </div>
            <div className="h-2 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full progress-bar transition-all" style={{ width: `${completionRate}%` }} />
            </div>
          </div>
        </div>

        {/* Social Links */}
        <div className="p-4 border-t border-white/5">
          <p className="text-xs text-zinc-500 mb-3">تواصل معنا</p>
          <div className="flex gap-2">
            {socialLinks.map(link => (
              <a
                key={link.name}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex-1 py-2 rounded-lg bg-gradient-to-r ${link.color} text-white text-center text-lg hover:opacity-80 transition-opacity`}
                title={link.name}
              >
                {link.icon}
              </a>
            ))}
          </div>
        </div>
      </aside>

      {/* MOBILE HEADER */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="p-2 rounded-lg bg-white/5">
            {showMobileMenu ? <Icons.X /> : <Icons.Menu />}
          </button>
          <h1 className="text-lg font-bold gradient-text">Arena</h1>
          <button onClick={() => setShowSearch(true)} className="p-2 rounded-lg bg-white/5">
            <Icons.Search />
          </button>
        </div>

        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className="absolute top-full left-0 right-0 glass border-t border-white/5 p-3 animate-fade max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-3 gap-2">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => { setView(item.id); setShowMobileMenu(false); }}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-all ${
                    view === item.id ? 'bg-violet-600/20 text-violet-400' : 'text-zinc-400'
                  }`}
                >
                  {item.icon}
                  <span className="text-[10px]">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* MOBILE BOTTOM NAV */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 glass border-t border-white/5">
        <div className="flex justify-around py-2">
          {[
            { id: 'home' as ViewMode, icon: <Icons.Home />, label: 'الرئيسية' },
            { id: 'files' as ViewMode, icon: <Icons.Folder />, label: 'ملفاتي' },
            { id: 'study' as ViewMode, icon: <Icons.Book />, label: 'ادرس' },
            { id: 'quiz' as ViewMode, icon: <Icons.Quiz />, label: 'اختبر' },
            { id: 'ai' as ViewMode, icon: <Icons.AI />, label: 'AI' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`flex flex-col items-center py-1 px-3 rounded-lg transition-all ${
                view === item.id ? 'text-violet-400' : 'text-zinc-500'
              }`}
            >
              {item.icon}
              <span className="text-[10px] mt-1">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* MAIN CONTENT */}
      <main className="lg:pr-64 pt-16 lg:pt-0 pb-20 lg:pb-0 min-h-screen">
        <div className="max-w-6xl mx-auto p-4 lg:p-8">
          {view === 'home' && <HomeView files={files} stats={stats} completionRate={completionRate} setView={setView} setShowUpload={setShowUpload} setSelectedFile={setSelectedFile} storageInfo={storageInfo} isLoading={isLoading} />}
          {view === 'files' && <FilesView files={files} setFiles={setFiles} onStudy={(f) => { setSelectedFile(f); setView('study'); }} onAdd={() => setShowUpload(true)} />}
          {view === 'study' && <StudyView files={files} setFiles={setFiles} selectedFile={selectedFile} setSelectedFile={setSelectedFile} />}
          {view === 'quiz' && <QuizView files={files} />}
          {view === 'flashcards' && <FlashcardsView files={files} />}
          {view === 'videos' && <VideosView videos={sampleVideos} />}
          {view === 'calendar' && <CalendarView events={sampleEvents} />}
          {view === 'faq' && <FAQView faqs={sampleFAQs} />}
          {view === 'ai' && <AIView files={files} />}
          {view === 'pomodoro' && <PomodoroView />}
          {view === 'stats' && <StatsView files={files} stats={stats} completionRate={completionRate} />}
          {view === 'support' && <SupportView />}
        </div>
      </main>

      {/* MODALS */}
      {showUpload && <UploadModal onClose={() => setShowUpload(false)} onAddFiles={(newFiles) => { setFiles(prev => [...prev, ...newFiles]); setShowUpload(false); }} />}
      {showSearch && <SearchModal query={searchQuery} setQuery={setSearchQuery} results={searchResults} onClose={() => { setShowSearch(false); setSearchQuery(''); }} setView={setView} />}

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-20 lg:bottom-8 left-4 z-50 flex flex-col gap-3 no-print">
        {/* WhatsApp */}
        <a
          href="https://wa.me/1234567890?text=مرحباً، لدي سؤال..."
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center text-white text-xl shadow-lg hover:scale-110 transition-transform"
          title="تواصل عبر واتساب"
        >
          💬
        </a>
        
        {/* Telegram */}
        <a
          href="https://t.me/studyai"
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center text-white text-xl shadow-lg hover:scale-110 transition-transform"
          title="تواصل عبر تليجرام"
        >
          📱
        </a>
        
        {/* Scroll to Top */}
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="w-12 h-12 rounded-full bg-gradient-to-r from-violet-500 to-purple-600 flex items-center justify-center text-white text-xl shadow-lg hover:scale-110 transition-transform animate-fade"
          >
            ↑
          </button>
        )}
      </div>

      {/* THEME TOGGLE (Fixed Top Left) */}
      <button
        onClick={() => setDarkMode(!darkMode)}
        className="fixed top-20 lg:top-4 left-4 z-50 w-12 h-12 rounded-full glass flex items-center justify-center text-xl hover:scale-110 transition-transform no-print"
        title={darkMode ? 'الوضع الفاتح' : 'الوضع المظلم'}
      >
        {darkMode ? '☀️' : '🌙'}
      </button>
    </div>
  );
}

// ============ HOME VIEW ============
function HomeView({ files, stats, completionRate, setView, setShowUpload, setSelectedFile, storageInfo, isLoading }: { 
  files: StudyFile[]; stats: any; completionRate: number; setView: (v: ViewMode) => void; setShowUpload: (v: boolean) => void; setSelectedFile: (f: StudyFile | null) => void; storageInfo: { used: number; total: number }; isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-violet-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-zinc-400">جاري تحميل ملفاتك...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-8 animate-fade">
      {/* Hero */}
      <div className="card p-8 lg:p-12 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-violet-600/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-cyan-600/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        <div className="relative">
          <span className="badge mb-4 inline-block">🎓 منصة تعليمية متكاملة</span>
          <h1 className="text-3xl lg:text-5xl font-bold mb-4">
            أهلاً بك في <span className="gradient-text">Arena</span>
          </h1>
          <p className="text-zinc-400 text-lg max-w-xl mb-8">
            ارفع ملفاتك واترك الذكاء الاصطناعي يلخصها ويشرحها ويختبرك عليها. تعلم بذكاء!
          </p>
          <div className="flex gap-4 flex-wrap">
            <button onClick={() => setShowUpload(true)} className="btn-primary px-6 py-3 rounded-xl flex items-center gap-2">
              <Icons.Plus /> إضافة ملف
            </button>
            <button onClick={() => setView('study')} className="btn-secondary px-6 py-3 rounded-xl">
              ابدأ الدراسة
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          { label: 'الملفات', value: stats.totalFiles, icon: '📁', color: 'from-blue-500 to-cyan-500' },
          { label: 'الأقسام', value: stats.totalSections, icon: '📑', color: 'from-purple-500 to-pink-500' },
          { label: 'المكتملة', value: stats.completedSections, icon: '✅', color: 'from-green-500 to-emerald-500' },
          { label: 'الأسئلة', value: stats.totalQuizzes, icon: '❓', color: 'from-orange-500 to-red-500' },
          { label: 'الإنجاز', value: `${completionRate}%`, icon: '🎯', color: 'from-violet-500 to-purple-500' },
        ].map((stat, i) => (
          <div key={i} className="card p-5 animate-fade" style={{ animationDelay: `${i * 0.05}s` }}>
            <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-lg mb-3`}>
              {stat.icon}
            </div>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="text-xs text-zinc-500">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4">⚡ إجراءات سريعة</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'اختبر نفسك', icon: '✍️', action: () => setView('quiz'), color: 'from-pink-500 to-rose-600' },
            { label: 'البطاقات', icon: '🃏', action: () => setView('flashcards'), color: 'from-cyan-500 to-blue-600' },
            { label: 'الفيديوهات', icon: '▶️', action: () => setView('videos'), color: 'from-red-500 to-orange-600' },
            { label: 'بومودورو', icon: '⏱️', action: () => setView('pomodoro'), color: 'from-emerald-500 to-green-600' },
          ].map((action, i) => (
            <button key={i} onClick={action.action} className="card p-5 text-right hover:scale-[1.02] transition-transform">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center text-xl mb-3`}>
                {action.icon}
              </div>
              <div className="text-white font-medium">{action.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Roadmap / Progress Section */}
      {files.length > 0 && (
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              🗺️ خارطة الطريق
            </h2>
            <div className="text-sm text-zinc-500">
              أكملت {stats.completedSections} من {stats.totalSections} قسم
            </div>
          </div>
          
          {/* Progress Overview */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-zinc-400">التقدم الكلي</span>
              <span className="text-violet-400 font-bold">{completionRate}%</span>
            </div>
            <div className="h-4 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full progress-bar transition-all duration-500" style={{ width: `${completionRate}%` }} />
            </div>
          </div>
          
          {/* Files Roadmap */}
          <div className="space-y-4">
            {files.slice(0, 5).map((file, i) => {
              const fileProgress = file.progress;
              const status = fileProgress === 100 ? 'completed' : fileProgress > 0 ? 'current' : 'pending';
              return (
                <div key={file.id} className="roadmap-item animate-fade" style={{ animationDelay: `${i * 0.1}s` }}>
                  <div className={`roadmap-dot ${status}`} />
                  <div 
                    className="card p-4 cursor-pointer hover:border-violet-500/50 transition-all"
                    onClick={() => { setSelectedFile(file); setView('study'); }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-white font-medium">{file.name}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        status === 'completed' ? 'bg-green-500/20 text-green-400' :
                        status === 'current' ? 'bg-violet-500/20 text-violet-400' :
                        'bg-white/5 text-zinc-500'
                      }`}>
                        {status === 'completed' ? '✅ مكتمل' : status === 'current' ? '📖 جاري' : '⏳ قادم'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2 bg-white/5 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all ${
                            status === 'completed' ? 'bg-green-500' : 'progress-bar'
                          }`} 
                          style={{ width: `${fileProgress}%` }} 
                        />
                      </div>
                      <span className="text-sm text-zinc-400">{fileProgress}%</span>
                    </div>
                    <div className="mt-2 text-xs text-zinc-500">
                      {file.sections.filter(s => s.isStudied).length} / {file.sections.length} أقسام مكتملة
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {files.length > 5 && (
            <button 
              onClick={() => setView('files')} 
              className="mt-4 text-violet-400 text-sm hover:underline w-full text-center"
            >
              عرض كل الملفات ({files.length}) ←
            </button>
          )}
        </div>
      )}

      {/* Levels Section */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4">📊 المستويات</h2>
        <div className="grid grid-cols-3 gap-4">
          {levels.map((level, i) => {
            const count = files.filter(f => f.level === level.id).length;
            const levelFiles = files.filter(f => f.level === level.id);
            const levelProgress = levelFiles.length > 0 
              ? Math.round(levelFiles.reduce((a, f) => a + f.progress, 0) / levelFiles.length) 
              : 0;
            return (
              <div key={i} className="card p-5 text-center hover:border-violet-500/50 transition-all">
                <div className="text-3xl mb-2">{level.icon}</div>
                <div className="text-white font-bold">{level.name}</div>
                <div className="text-zinc-500 text-sm">{count} ملفات</div>
                <div className={`mt-3 inline-block px-3 py-1 rounded-full text-xs text-white ${level.color}`}>
                  {levelProgress}% مكتمل
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* All Files */}
      {files.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">📂 ملفاتك الدراسية ({files.length})</h2>
            <button onClick={() => setView('files')} className="text-violet-400 text-sm hover:underline flex items-center gap-1">
              إدارة الملفات <Icons.Arrow />
            </button>
          </div>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {files.map((file, i) => {
              const cat = categories.find(c => c.id === file.category) || categories[0];
              const level = levels.find(l => l.id === file.level);
              return (
                <div 
                  key={file.id} 
                  className="card p-4 cursor-pointer glass-hover animate-fade" 
                  style={{ animationDelay: `${i * 0.03}s` }}
                  onClick={() => { setSelectedFile(file); setView('study'); }}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-lg flex-shrink-0`}>
                      {cat.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-white font-medium truncate text-sm">{file.name}</div>
                      <div className="text-xs text-zinc-500 mt-0.5">{file.sections.length} قسم</div>
                    </div>
                    {level && (
                      <span className={`px-2 py-0.5 rounded text-[10px] ${level.color} text-white`}>
                        {level.icon}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full progress-bar" style={{ width: `${file.progress}%` }} />
                    </div>
                    <span className="text-xs text-zinc-400">{file.progress}%</span>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Quick Stats Bar */}
          <div className="mt-4 card p-4 flex items-center justify-around text-center flex-wrap gap-4">
            <div>
              <div className="text-2xl font-bold text-white">{files.length}</div>
              <div className="text-xs text-zinc-500">ملفات</div>
            </div>
            <div className="w-px h-8 bg-white/10 hidden sm:block" />
            <div>
              <div className="text-2xl font-bold text-white">{stats.totalSections}</div>
              <div className="text-xs text-zinc-500">أقسام</div>
            </div>
            <div className="w-px h-8 bg-white/10 hidden sm:block" />
            <div>
              <div className="text-2xl font-bold text-green-400">{stats.completedSections}</div>
              <div className="text-xs text-zinc-500">مكتمل</div>
            </div>
            <div className="w-px h-8 bg-white/10 hidden sm:block" />
            <div>
              <div className="text-2xl font-bold gradient-text">{completionRate}%</div>
              <div className="text-xs text-zinc-500">إنجاز</div>
            </div>
            {storageInfo.total > 0 && (
              <>
                <div className="w-px h-8 bg-white/10 hidden sm:block" />
                <div>
                  <div className="text-2xl font-bold text-cyan-400">{storageInfo.used}MB</div>
                  <div className="text-xs text-zinc-500">مستخدم من {storageInfo.total}MB</div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Upcoming Events */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">📅 الأحداث القادمة</h2>
          <button onClick={() => setView('calendar')} className="text-violet-400 text-sm hover:underline">
            عرض الجدول ←
          </button>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {sampleEvents.slice(0, 3).map(event => (
            <div key={event.id} className="card p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className={`w-2 h-2 rounded-full ${
                  event.type === 'exam' ? 'bg-red-500' : event.type === 'lecture' ? 'bg-green-500' : 'bg-yellow-500'
                }`} />
                <span className="text-xs text-zinc-500">
                  {event.type === 'exam' ? 'اختبار' : event.type === 'lecture' ? 'محاضرة' : 'موعد نهائي'}
                </span>
              </div>
              <h3 className="text-white font-medium mb-1">{event.title}</h3>
              <p className="text-xs text-zinc-500">
                {event.date.toLocaleDateString('ar-EG')} - {event.time}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {files.length === 0 && (
        <div className="card p-12 text-center">
          <div className="text-6xl mb-4 animate-float">📚</div>
          <h3 className="text-2xl font-bold text-white mb-3">ابدأ رحلتك التعليمية</h3>
          <p className="text-zinc-400 mb-6 max-w-md mx-auto">
            أضف ملفاتك الدراسية وسيقوم الذكاء الاصطناعي بتحليلها وتلخيصها وإنشاء اختبارات لك
          </p>
          <button onClick={() => setShowUpload(true)} className="btn-primary px-8 py-4 rounded-xl text-lg">
            🚀 أضف أول ملف
          </button>
        </div>
      )}
    </div>
  );
}

// ============ FILES VIEW ============
function FilesView({ files, setFiles, onStudy, onAdd }: { files: StudyFile[]; setFiles: (f: StudyFile[]) => void; onStudy: (f: StudyFile) => void; onAdd: () => void }) {
  const [filter, setFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');

  const filtered = files.filter(f => {
    const catMatch = filter === 'all' || f.category === filter;
    const levelMatch = levelFilter === 'all' || f.level === levelFilter;
    return catMatch && levelMatch;
  });

  return (
    <div className="space-y-6 animate-fade">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">📁 ملفاتي</h1>
          <p className="text-zinc-500 text-sm">{files.length} ملف دراسي</p>
        </div>
        <button onClick={onAdd} className="btn-primary px-5 py-2.5 rounded-xl flex items-center gap-2">
          <Icons.Plus /> إضافة ملف
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex gap-2 overflow-x-auto pb-2 flex-1">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
                filter === cat.id ? 'bg-violet-600 text-white' : 'bg-white/5 text-zinc-400 hover:bg-white/10'
              }`}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {levels.map(level => (
            <button
              key={level.id}
              onClick={() => setLevelFilter(levelFilter === level.id ? 'all' : level.id)}
              className={`px-3 py-2 rounded-lg text-sm transition-all ${
                levelFilter === level.id ? `${level.color} text-white` : 'bg-white/5 text-zinc-400'
              }`}
            >
              {level.icon}
            </button>
          ))}
        </div>
      </div>

      {/* Files Grid */}
      <div className="grid gap-4 md:grid-cols-2">
        {filtered.map((file, i) => {
          const cat = categories.find(c => c.id === file.category) || categories[0];
          const level = levels.find(l => l.id === file.level) || levels[0];
          return (
            <div key={file.id} className="card p-5 animate-fade" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="flex items-start gap-4 mb-4">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-2xl flex-shrink-0`}>
                  {cat.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-bold truncate">{file.name}</h3>
                  <p className="text-sm text-zinc-500">{cat.name}</p>
                  <span className={`inline-block mt-1 px-2 py-0.5 rounded text-xs ${level.color} text-white`}>
                    {level.name}
                  </span>
                </div>
                <button onClick={() => setFiles(files.filter(f => f.id !== file.id))} className="p-2 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10">
                  <Icons.Trash />
                </button>
              </div>

              <div className="flex gap-2 mb-4 flex-wrap">
                <span className="px-2 py-1 bg-white/5 rounded text-xs text-zinc-400">📑 {file.sections.length} قسم</span>
                <span className="px-2 py-1 bg-white/5 rounded text-xs text-zinc-400">✅ {file.sections.filter(s => s.isStudied).length} مدروس</span>
                <span className="px-2 py-1 bg-white/5 rounded text-xs text-zinc-400">❓ {file.sections.reduce((a, s) => a + s.quiz.length, 0)} سؤال</span>
              </div>

              <div className="mb-4">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>التقدم</span>
                  <span>{file.progress}%</span>
                </div>
                <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full progress-bar" style={{ width: `${file.progress}%` }} />
                </div>
              </div>

              <div className="flex gap-2">
                <button onClick={() => onStudy(file)} className="flex-1 btn-primary py-2.5 rounded-xl flex items-center justify-center gap-2">
                  <Icons.Play /> ادرس
                </button>
                <button className="btn-secondary p-2.5 rounded-xl" title="تحميل">
                  <Icons.Download />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-4">📭</div>
          <p className="text-zinc-400">{files.length === 0 ? 'لا توجد ملفات بعد' : 'لا توجد ملفات بهذا التصنيف'}</p>
        </div>
      )}
    </div>
  );
}

// ============ STUDY VIEW ============
function StudyView({ files, setFiles, selectedFile, setSelectedFile }: { files: StudyFile[]; setFiles: (f: StudyFile[]) => void; selectedFile: StudyFile | null; setSelectedFile: (f: StudyFile | null) => void }) {
  const [activeSection, setActiveSection] = useState(0);
  const [activeTab, setActiveTab] = useState<'content' | 'summary' | 'keypoints' | 'explanation' | 'notes' | 'discuss'>('content');
  const [newComment, setNewComment] = useState('');
  const [comments, setComments] = useState<{id: string; text: string; time: Date}[]>(() => {
    try {
      const saved = localStorage.getItem('arena_comments_' + selectedFile?.id);
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  
  // Save comments
  useEffect(() => {
    if (selectedFile) {
      localStorage.setItem('arena_comments_' + selectedFile.id, JSON.stringify(comments));
    }
  }, [comments, selectedFile]);
  
  const addComment = () => {
    if (!newComment.trim()) return;
    setComments(prev => [...prev, { id: Date.now().toString(), text: newComment.trim(), time: new Date() }]);
    setNewComment('');
  };

  if (!selectedFile) {
    return (
      <div className="space-y-6 animate-fade">
        <h1 className="text-2xl font-bold text-white">📖 اختر ملفاً للدراسة</h1>
        <div className="grid gap-4 md:grid-cols-2">
          {files.map(file => {
            const cat = categories.find(c => c.id === file.category) || categories[0];
            return (
              <button key={file.id} onClick={() => { setSelectedFile(file); setActiveSection(0); }} className="card p-5 text-right hover:border-violet-500/50">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-2xl`}>{cat.icon}</div>
                  <div className="flex-1">
                    <div className="text-white font-bold">{file.name}</div>
                    <div className="text-sm text-zinc-500">{file.sections.length} قسم • {file.progress}%</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
        {files.length === 0 && <div className="card p-12 text-center"><div className="text-5xl mb-4">📚</div><p className="text-zinc-400">أضف ملفات أولاً</p></div>}
      </div>
    );
  }

  const section = selectedFile.sections[activeSection];
  const toggleStudied = () => {
    const updated = files.map(f => {
      if (f.id !== selectedFile.id) return f;
      const sections = f.sections.map((s, i) => i === activeSection ? { ...s, isStudied: !s.isStudied } : s);
      const progress = Math.round((sections.filter(s => s.isStudied).length / sections.length) * 100);
      return { ...f, sections, progress };
    });
    setFiles(updated);
    setSelectedFile(updated.find(f => f.id === selectedFile.id) || null);
  };

  const updateNotes = (notes: string) => {
    const updated = files.map(f => {
      if (f.id !== selectedFile.id) return f;
      return { ...f, sections: f.sections.map((s, i) => i === activeSection ? { ...s, notes } : s) };
    });
    setFiles(updated);
    setSelectedFile(updated.find(f => f.id === selectedFile.id) || null);
  };

  return (
    <div className="space-y-4 animate-fade">
      <div className="card p-4 flex items-center gap-4">
        <button onClick={() => setSelectedFile(null)} className="p-2 rounded-lg bg-white/5 text-zinc-400 hover:text-white"><Icons.ArrowLeft /></button>
        <div className="flex-1"><h2 className="text-white font-bold">{selectedFile.name}</h2><p className="text-xs text-zinc-500">{selectedFile.sections.length} قسم</p></div>
        <div className="hidden sm:block w-32 h-2 bg-white/5 rounded-full overflow-hidden"><div className="h-full progress-bar" style={{ width: `${selectedFile.progress}%` }} /></div>
        <span className="text-violet-400 font-bold">{selectedFile.progress}%</span>
      </div>

      <div className="flex gap-4 flex-col lg:flex-row">
        <div className="lg:w-64 flex-shrink-0">
          <div className="card p-3 space-y-1 max-h-[60vh] overflow-y-auto lg:sticky lg:top-4">
            <h3 className="text-xs text-zinc-500 px-3 mb-2">الأقسام</h3>
            {selectedFile.sections.map((s, i) => (
              <button key={s.id} onClick={() => { setActiveSection(i); setActiveTab('content'); }} className={`w-full text-right px-3 py-2.5 rounded-lg flex items-center gap-2 transition-all ${i === activeSection ? 'bg-violet-600/20 text-white' : 'text-zinc-400 hover:bg-white/5'}`}>
                <span className={`w-6 h-6 rounded flex items-center justify-center text-xs ${s.isStudied ? 'bg-green-500/20 text-green-400' : 'bg-white/5'}`}>{s.isStudied ? '✓' : i + 1}</span>
                <span className="text-sm truncate flex-1">{s.title}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 space-y-4">
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
              <h3 className="text-xl font-bold text-white">{section.title}</h3>
              <button onClick={toggleStudied} className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${section.isStudied ? 'bg-green-500/20 text-green-400' : 'bg-white/5 text-zinc-400 hover:bg-violet-600/20'}`}>
                {section.isStudied ? '✅ تم' : '⬜ تحديد كمدروس'}
              </button>
            </div>

            <div className="flex gap-1 bg-white/5 rounded-lg p-1 mb-4 overflow-x-auto">
              {[{ id: 'content', label: 'المحتوى', icon: '📄' }, { id: 'summary', label: 'الملخص', icon: '📋' }, { id: 'keypoints', label: 'النقاط', icon: '🔑' }, { id: 'explanation', label: 'الشرح', icon: '💡' }, { id: 'notes', label: 'ملاحظاتي', icon: '✏️' }, { id: 'discuss', label: 'مناقشة', icon: '💬' }].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id as typeof activeTab)} className={`px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-all ${activeTab === tab.id ? 'bg-violet-600 text-white' : 'text-zinc-400 hover:text-white'}`}>{tab.icon} {tab.label}</button>
              ))}
            </div>

            <div className="min-h-[300px] animate-fade" key={activeTab}>
              {activeTab === 'content' && <div className="prose prose-invert max-w-none">{section.content.split('\n').map((line, i) => <p key={i} className="text-zinc-300 leading-relaxed mb-2">{line || '\u00A0'}</p>)}</div>}
              {activeTab === 'summary' && <div className="p-4 bg-violet-600/10 rounded-xl border border-violet-500/20"><p className="text-zinc-300 leading-relaxed">{section.summary}</p></div>}
              {activeTab === 'keypoints' && <div className="space-y-3">{section.keyPoints.map((point, i) => <div key={i} className="flex gap-3 p-3 bg-white/5 rounded-xl"><span className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">{i + 1}</span><p className="text-zinc-300 pt-1">{point}</p></div>)}</div>}
              {activeTab === 'explanation' && <div className="p-4 bg-cyan-600/10 rounded-xl border border-cyan-500/20">{section.explanation.split('\n').map((line, i) => <p key={i} className="text-zinc-300 leading-relaxed mb-2">{line}</p>)}</div>}
              {activeTab === 'notes' && <textarea value={section.notes} onChange={(e) => updateNotes(e.target.value)} placeholder="اكتب ملاحظاتك هنا..." className="w-full h-64 input resize-none" />}
              {activeTab === 'discuss' && (
                <div className="space-y-4">
                  {/* Add Comment */}
                  <div className="flex gap-3">
                    <input
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addComment()}
                      placeholder="اكتب سؤالك أو تعليقك هنا..."
                      className="flex-1 input"
                    />
                    <button onClick={addComment} className="btn-primary px-5 rounded-xl" disabled={!newComment.trim()}>
                      إرسال
                    </button>
                  </div>
                  
                  {/* Comments List */}
                  <div className="space-y-3">
                    {comments.length === 0 && (
                      <div className="text-center py-8 text-zinc-500">
                        <div className="text-4xl mb-2">💬</div>
                        <p>لا توجد تعليقات بعد. كن أول من يسأل!</p>
                      </div>
                    )}
                    {comments.map((comment) => (
                      <div key={comment.id} className="comment-box border-violet-500 p-4 bg-white/5 rounded-xl">
                        <p className="text-zinc-300">{comment.text}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-zinc-500">
                            {new Date(comment.time).toLocaleDateString('ar-EG')} - {new Date(comment.time).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <button 
                            onClick={() => setComments(prev => prev.filter(c => c.id !== comment.id))}
                            className="text-xs text-red-400 hover:text-red-300"
                          >
                            حذف
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-between">
            <button onClick={() => { setActiveSection(Math.max(0, activeSection - 1)); setActiveTab('content'); }} disabled={activeSection === 0} className="px-5 py-2.5 rounded-xl btn-secondary disabled:opacity-30">→ السابق</button>
            <button onClick={() => { setActiveSection(Math.min(selectedFile.sections.length - 1, activeSection + 1)); setActiveTab('content'); }} disabled={activeSection === selectedFile.sections.length - 1} className="px-5 py-2.5 rounded-xl btn-primary disabled:opacity-30">التالي ←</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ QUIZ VIEW ============
function QuizView({ files }: { files: StudyFile[] }) {
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResult, setShowResult] = useState(false);

  const allQuestions = files.flatMap(f => f.sections.flatMap(s => s.quiz));
  const questions = selectedFileId === 'all' ? allQuestions : selectedFileId ? files.find(f => f.id === selectedFileId)?.sections.flatMap(s => s.quiz) || [] : [];

  if (!selectedFileId) {
    return (
      <div className="space-y-6 animate-fade">
        <h1 className="text-2xl font-bold text-white">✍️ الاختبارات</h1>
        {allQuestions.length > 0 && (
          <button onClick={() => setSelectedFileId('all')} className="card p-5 w-full text-right hover:border-violet-500/50">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-2xl">🎯</div>
              <div><div className="text-white font-bold">اختبار شامل</div><div className="text-sm text-zinc-500">{allQuestions.length} سؤال</div></div>
            </div>
          </button>
        )}
        <div className="grid gap-4 md:grid-cols-2">
          {files.filter(f => f.sections.some(s => s.quiz.length > 0)).map(file => (
            <button key={file.id} onClick={() => setSelectedFileId(file.id)} className="card p-5 text-right hover:border-violet-500/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-xl">📝</div>
                <div><div className="text-white font-medium">{file.name}</div><div className="text-sm text-zinc-500">{file.sections.reduce((a, s) => a + s.quiz.length, 0)} سؤال</div></div>
              </div>
            </button>
          ))}
        </div>
        {allQuestions.length === 0 && <div className="card p-12 text-center"><div className="text-5xl mb-4">✍️</div><p className="text-zinc-400">أضف ملفات لإنشاء اختبارات</p></div>}
      </div>
    );
  }

  if (showResult) {
    const correct = questions.filter(q => answers[q.id] === q.correctAnswer).length;
    const percentage = Math.round((correct / questions.length) * 100);
    return (
      <div className="max-w-xl mx-auto space-y-6 animate-fade">
        <div className="card p-8 text-center">
          <div className="text-6xl mb-4">{percentage >= 70 ? '🎉' : percentage >= 50 ? '😊' : '😅'}</div>
          <h2 className="text-2xl font-bold text-white mb-2">النتيجة</h2>
          <div className="text-5xl font-bold gradient-text mb-4">{percentage}%</div>
          <p className="text-zinc-400 mb-6">{correct} من {questions.length} صحيح</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => { setCurrentQ(0); setAnswers({}); setShowResult(false); }} className="btn-primary px-6 py-3 rounded-xl">إعادة</button>
            <button onClick={() => { setSelectedFileId(null); setCurrentQ(0); setAnswers({}); setShowResult(false); }} className="btn-secondary px-6 py-3 rounded-xl">رجوع</button>
          </div>
        </div>
      </div>
    );
  }

  const question = questions[currentQ];
  if (!question) return null;
  const answered = answers[question.id] !== undefined;

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade">
      <div className="card p-4 flex items-center justify-between">
        <button onClick={() => setSelectedFileId(null)} className="text-zinc-400 hover:text-white">← رجوع</button>
        <span className="text-zinc-500">{currentQ + 1} / {questions.length}</span>
      </div>
      <div className="h-2 bg-white/5 rounded-full overflow-hidden"><div className="h-full progress-bar" style={{ width: `${((currentQ + 1) / questions.length) * 100}%` }} /></div>
      <div className="card p-6">
        <h3 className="text-lg font-bold text-white mb-6">{question.question}</h3>
        <div className="space-y-3">
          {question.options.map((opt, i) => {
            let style = 'bg-white/5 text-zinc-300 hover:bg-white/10 cursor-pointer border-transparent';
            if (answered) {
              if (i === question.correctAnswer) style = 'bg-green-500/20 text-green-400 border-green-500/50';
              else if (i === answers[question.id]) style = 'bg-red-500/20 text-red-400 border-red-500/50';
              else style = 'bg-white/5 text-zinc-500 border-transparent';
            }
            return (
              <button key={i} onClick={() => !answered && setAnswers({ ...answers, [question.id]: i })} disabled={answered} className={`w-full p-4 rounded-xl text-right border transition-all ${style}`}>
                <span className="inline-flex w-8 h-8 rounded-lg bg-white/10 items-center justify-center text-sm ml-3">{answered && i === question.correctAnswer ? '✓' : answered && i === answers[question.id] ? '✗' : String.fromCharCode(1571 + i)}</span>{opt}
              </button>
            );
          })}
        </div>
        {answered && <div className="mt-4 p-4 bg-violet-600/10 rounded-xl border border-violet-500/20 animate-fade"><p className="text-zinc-300 text-sm">{question.explanation}</p></div>}
        {answered && <button onClick={() => currentQ < questions.length - 1 ? setCurrentQ(currentQ + 1) : setShowResult(true)} className="w-full mt-4 btn-primary py-3 rounded-xl">{currentQ < questions.length - 1 ? 'التالي ←' : 'النتيجة 🎯'}</button>}
      </div>
    </div>
  );
}

// ============ FLASHCARDS VIEW ============
function FlashcardsView({ files }: { files: StudyFile[] }) {
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [currentCard, setCurrentCard] = useState(0);
  const [flipped, setFlipped] = useState(false);

  const allCards = files.flatMap(f => f.sections.flatMap(s => s.flashcards));
  const cards = selectedFileId === 'all' ? allCards : selectedFileId ? files.find(f => f.id === selectedFileId)?.sections.flatMap(s => s.flashcards) || [] : [];

  if (!selectedFileId) {
    return (
      <div className="space-y-6 animate-fade">
        <h1 className="text-2xl font-bold text-white">🃏 البطاقات التعليمية</h1>
        {allCards.length > 0 && <button onClick={() => setSelectedFileId('all')} className="card p-5 w-full text-right hover:border-violet-500/50"><div className="flex items-center gap-4"><div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-2xl">🎴</div><div><div className="text-white font-bold">جميع البطاقات</div><div className="text-sm text-zinc-500">{allCards.length} بطاقة</div></div></div></button>}
        <div className="grid gap-4 md:grid-cols-2">{files.filter(f => f.sections.some(s => s.flashcards.length > 0)).map(file => (<button key={file.id} onClick={() => setSelectedFileId(file.id)} className="card p-5 text-right hover:border-violet-500/50"><div className="flex items-center gap-4"><div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-xl">🃏</div><div><div className="text-white font-medium">{file.name}</div><div className="text-sm text-zinc-500">{file.sections.reduce((a, s) => a + s.flashcards.length, 0)} بطاقة</div></div></div></button>))}</div>
        {allCards.length === 0 && <div className="card p-12 text-center"><div className="text-5xl mb-4">🃏</div><p className="text-zinc-400">أضف ملفات لإنشاء بطاقات</p></div>}
      </div>
    );
  }

  const card = cards[currentCard];
  if (!card) return null;

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade">
      <div className="flex items-center justify-between"><button onClick={() => { setSelectedFileId(null); setCurrentCard(0); setFlipped(false); }} className="text-zinc-400 hover:text-white">← رجوع</button><span className="text-zinc-500">{currentCard + 1} / {cards.length}</span></div>
      <div onClick={() => setFlipped(!flipped)} className="card p-8 min-h-[300px] flex items-center justify-center cursor-pointer hover:border-violet-500/50"><div className="text-center"><p className="text-xl text-white mb-4">{flipped ? card.back : card.front}</p><p className="text-xs text-zinc-500">{flipped ? 'الإجابة' : 'اضغط للقلب'}</p></div></div>
      <div className="flex gap-3"><button onClick={() => { setCurrentCard(Math.max(0, currentCard - 1)); setFlipped(false); }} disabled={currentCard === 0} className="flex-1 btn-secondary py-3 rounded-xl disabled:opacity-30">→ السابقة</button><button onClick={() => { setCurrentCard(Math.min(cards.length - 1, currentCard + 1)); setFlipped(false); }} disabled={currentCard === cards.length - 1} className="flex-1 btn-primary py-3 rounded-xl disabled:opacity-30">التالية ←</button></div>
    </div>
  );
}

// ============ VIDEOS VIEW ============
function VideosView({ videos }: { videos: Video[] }) {
  const [filter, setFilter] = useState('all');
  const playlists = [...new Set(videos.map(v => v.playlist).filter(Boolean))] as string[];
  const filtered = filter === 'all' ? videos : videos.filter(v => v.playlist === filter || v.category === filter);

  return (
    <div className="space-y-6 animate-fade">
      <h1 className="text-2xl font-bold text-white">▶️ مكتبة الفيديوهات</h1>
      
      {/* Playlists */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${filter === 'all' ? 'bg-violet-600 text-white' : 'bg-white/5 text-zinc-400'}`}>الكل</button>
        {playlists.map(pl => (<button key={pl} onClick={() => setFilter(pl)} className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${filter === pl ? 'bg-violet-600 text-white' : 'bg-white/5 text-zinc-400'}`}>📁 {pl}</button>))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map(video => {
          const level = levels.find(l => l.id === video.level);
          return (
            <a key={video.id} href={video.url} target="_blank" rel="noopener noreferrer" className="card overflow-hidden group">
              <div className="relative aspect-video bg-zinc-800">
                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-14 h-14 rounded-full bg-violet-600 flex items-center justify-center text-white"><Icons.Play /></div>
                </div>
                <span className="absolute bottom-2 left-2 bg-black/80 px-2 py-0.5 rounded text-xs text-white">{video.duration}</span>
                {level && <span className={`absolute top-2 right-2 px-2 py-0.5 rounded text-xs text-white ${level.color}`}>{level.name}</span>}
              </div>
              <div className="p-4">
                <h3 className="text-white font-medium mb-1 line-clamp-1">{video.title}</h3>
                <p className="text-xs text-zinc-500 line-clamp-2 mb-2">{video.description}</p>
                <div className="flex items-center text-xs text-zinc-500"><span>{video.views.toLocaleString()} مشاهدة</span></div>
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}

// ============ CALENDAR VIEW ============
function CalendarView({ events }: { events: Event[] }) {
  const [currentDate] = useState(new Date());
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const monthName = currentDate.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' });

  const getEventsForDay = (day: number) => events.filter(e => {
    const d = new Date(e.date);
    return d.getDate() === day && d.getMonth() === currentDate.getMonth();
  });

  return (
    <div className="space-y-6 animate-fade">
      <h1 className="text-2xl font-bold text-white">📅 الجدول الزمني</h1>
      
      <div className="card p-6">
        <h2 className="text-xl font-bold text-white text-center mb-6">{monthName}</h2>
        <div className="grid grid-cols-7 gap-2 mb-4">
          {['أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'].map(d => (<div key={d} className="text-center text-xs text-zinc-500 py-2">{d}</div>))}
        </div>
        <div className="grid grid-cols-7 gap-2">
          {Array(firstDay).fill(null).map((_, i) => <div key={`empty-${i}`} />)}
          {days.map(day => {
            const dayEvents = getEventsForDay(day);
            const isToday = day === new Date().getDate() && currentDate.getMonth() === new Date().getMonth();
            return (
              <div key={day} className={`calendar-day ${isToday ? 'active' : ''} ${dayEvents.length ? 'has-event' : ''}`}>
                {day}
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-white mb-4">📋 الأحداث القادمة</h2>
        <div className="space-y-3">
          {events.map(event => (
            <div key={event.id} className="card p-4 flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${
                event.type === 'exam' ? 'bg-red-500/20' : event.type === 'lecture' ? 'bg-green-500/20' : 'bg-yellow-500/20'
              }`}>
                {event.type === 'exam' ? '📝' : event.type === 'lecture' ? '🎓' : '⏰'}
              </div>
              <div className="flex-1">
                <h3 className="text-white font-medium">{event.title}</h3>
                <p className="text-xs text-zinc-500">{event.description}</p>
                <p className="text-xs text-violet-400 mt-1">{event.date.toLocaleDateString('ar-EG')} - {event.time}</p>
              </div>
              {event.link && <a href={event.link} target="_blank" rel="noopener noreferrer" className="btn-secondary p-2 rounded-lg"><Icons.ExternalLink /></a>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============ FAQ VIEW ============
function FAQView({ faqs }: { faqs: FAQ[] }) {
  const [openId, setOpenId] = useState<string | null>(null);
  const [filter, setFilter] = useState('all');
  const faqCategories = [...new Set(faqs.map(f => f.category))];
  const filtered = filter === 'all' ? faqs : faqs.filter(f => f.category === filter);

  return (
    <div className="space-y-6 animate-fade">
      <h1 className="text-2xl font-bold text-white">❓ الأسئلة الشائعة</h1>
      
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-lg text-sm ${filter === 'all' ? 'bg-violet-600 text-white' : 'bg-white/5 text-zinc-400'}`}>الكل</button>
        {faqCategories.map(cat => (<button key={cat} onClick={() => setFilter(cat)} className={`px-4 py-2 rounded-lg text-sm ${filter === cat ? 'bg-violet-600 text-white' : 'bg-white/5 text-zinc-400'}`}>{cat}</button>))}
      </div>

      <div className="space-y-3">
        {filtered.map(faq => (
          <div key={faq.id} className="card overflow-hidden">
            <button onClick={() => setOpenId(openId === faq.id ? null : faq.id)} className="w-full p-4 flex items-center gap-4 text-right">
              <div className="w-10 h-10 rounded-lg bg-violet-600/20 flex items-center justify-center text-lg">❓</div>
              <span className="flex-1 text-white font-medium">{faq.question}</span>
              <span className={`transition-transform ${openId === faq.id ? 'rotate-180' : ''}`}>▼</span>
            </button>
            {openId === faq.id && (
              <div className="px-4 pb-4 animate-fade">
                <p className="text-zinc-400 leading-relaxed pr-14">{faq.answer}</p>
                <div className="flex items-center gap-2 mt-3 pr-14">
                  <span className="text-xs text-zinc-500">هل كان مفيداً؟</span>
                  <button className="flex items-center gap-1 text-xs text-zinc-400 hover:text-green-400"><Icons.ThumbUp /> {faq.helpful}</button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ AI VIEW ============
function AIView({ files }: { files: StudyFile[] }) {
  const [messages, setMessages] = useState<Message[]>([{ id: '1', role: 'ai', content: `مرحباً! أنا مساعدك الذكي 🤖\n\nيمكنني:\n• تلخيص ملفاتك\n• شرح المفاهيم\n• الإجابة على أسئلتك\n• إنشاء اختبارات\n\nلديك ${files.length} ملفات. كيف أساعدك؟`, timestamp: new Date() }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = () => {
    if (!input.trim() || loading) return;
    const question = input.trim();
    setMessages(m => [...m, { id: Date.now().toString(), role: 'user', content: question, timestamp: new Date() }]);
    setInput('');
    setLoading(true);

    setTimeout(() => {
      const filesData = files.map(f => ({ name: f.name, content: f.content, sections: f.sections.map(s => ({ title: s.title, content: s.content, summary: s.summary })) }));
      const response = generateAIResponse(question, filesData);
      setMessages(m => [...m, { id: Date.now().toString(), role: 'ai', content: response, timestamp: new Date() }]);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col animate-fade">
      <h1 className="text-2xl font-bold text-white mb-4">🤖 مساعد AI</h1>
      
      <div className="flex-1 card p-4 overflow-y-auto space-y-4 mb-4">
        {messages.map(m => (
          <div key={m.id} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${m.role === 'ai' ? 'bg-violet-600' : 'bg-cyan-600'}`}>{m.role === 'ai' ? '🤖' : '👤'}</div>
            <div className={`max-w-[80%] p-4 rounded-2xl ${m.role === 'ai' ? 'bg-white/5' : 'bg-violet-600/20'}`}><p className="text-zinc-300 text-sm whitespace-pre-wrap">{m.content}</p></div>
          </div>
        ))}
        {loading && <div className="flex gap-3"><div className="w-8 h-8 rounded-lg bg-violet-600 flex items-center justify-center">🤖</div><div className="bg-white/5 p-4 rounded-2xl flex gap-1"><div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" /><div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} /><div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} /></div></div>}
        <div ref={endRef} />
      </div>

      <div className="flex gap-3">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="اكتب سؤالك..." className="flex-1 input" />
        <button onClick={send} disabled={!input.trim() || loading} className="btn-primary px-5 rounded-xl disabled:opacity-50"><Icons.Send /></button>
      </div>
    </div>
  );
}

// ============ POMODORO VIEW ============
function PomodoroView() {
  const [time, setTime] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const [sessions, setSessions] = useState(0);

  useEffect(() => {
    if (!isRunning) return;
    const timer = setInterval(() => {
      setTime(t => {
        if (t <= 1) {
          setIsRunning(false);
          if (mode === 'work') setSessions(s => s + 1);
          setMode(m => m === 'work' ? 'break' : 'work');
          return mode === 'work' ? 5 * 60 : 25 * 60;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isRunning, mode]);

  const mins = Math.floor(time / 60);
  const secs = time % 60;

  return (
    <div className="max-w-md mx-auto space-y-8 animate-fade">
      <h1 className="text-2xl font-bold text-white text-center">⏱️ تقنية بومودورو</h1>
      
      <div className="card p-8 text-center">
        <div className={`text-sm font-medium mb-4 ${mode === 'work' ? 'text-violet-400' : 'text-green-400'}`}>{mode === 'work' ? '🎯 وقت الدراسة' : '☕ راحة'}</div>
        <div className="text-7xl font-bold text-white mb-4 font-mono">{String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}</div>
        <div className="text-sm text-zinc-500 mb-6">الجلسات المكتملة: {sessions}</div>
        <div className="flex gap-4 justify-center">
          <button onClick={() => setIsRunning(!isRunning)} className={`px-8 py-4 rounded-xl font-medium text-lg ${isRunning ? 'bg-red-500/20 text-red-400' : 'btn-primary'}`}>{isRunning ? '⏸ إيقاف' : '▶️ بدء'}</button>
          <button onClick={() => { setTime(mode === 'work' ? 25 * 60 : 5 * 60); setIsRunning(false); }} className="btn-secondary px-6 py-4 rounded-xl">🔄</button>
        </div>
      </div>

      <div className="flex gap-3">
        <button onClick={() => { setMode('work'); setTime(25 * 60); setIsRunning(false); }} className={`flex-1 p-4 rounded-xl ${mode === 'work' ? 'bg-violet-600/20 text-violet-400 border border-violet-500/50' : 'bg-white/5 text-zinc-400'}`}>🎯 دراسة</button>
        <button onClick={() => { setMode('break'); setTime(5 * 60); setIsRunning(false); }} className={`flex-1 p-4 rounded-xl ${mode === 'break' ? 'bg-green-600/20 text-green-400 border border-green-500/50' : 'bg-white/5 text-zinc-400'}`}>☕ راحة</button>
      </div>
    </div>
  );
}

// ============ STATS VIEW ============
function StatsView({ files, stats, completionRate }: { files: StudyFile[]; stats: any; completionRate: number }) {
  return (
    <div className="space-y-6 animate-fade">
      <h1 className="text-2xl font-bold text-white">📊 الإحصائيات</h1>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[{ label: 'الملفات', value: stats.totalFiles, icon: '📁' }, { label: 'الأقسام', value: stats.totalSections, icon: '📑' }, { label: 'المكتملة', value: stats.completedSections, icon: '✅' }, { label: 'الأسئلة', value: stats.totalQuizzes, icon: '❓' }].map((s, i) => (
          <div key={i} className="card p-5"><div className="text-2xl mb-2">{s.icon}</div><div className="text-3xl font-bold text-white">{s.value}</div><div className="text-sm text-zinc-500">{s.label}</div></div>
        ))}
      </div>

      <div className="card p-6">
        <h3 className="text-lg font-bold text-white mb-4">📈 نسبة الإنجاز</h3>
        <div className="flex items-center gap-6">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 -rotate-90"><circle cx="64" cy="64" r="56" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="12" /><circle cx="64" cy="64" r="56" fill="none" stroke="url(#grad)" strokeWidth="12" strokeDasharray={`${2 * Math.PI * 56}`} strokeDashoffset={`${2 * Math.PI * 56 * (1 - completionRate / 100)}`} strokeLinecap="round" /><defs><linearGradient id="grad"><stop offset="0%" stopColor="#8b5cf6" /><stop offset="100%" stopColor="#06b6d4" /></linearGradient></defs></svg>
            <div className="absolute inset-0 flex items-center justify-center"><span className="text-2xl font-bold text-white">{completionRate}%</span></div>
          </div>
          <div><p className="text-zinc-400">أكملت {stats.completedSections} من {stats.totalSections} قسم</p></div>
        </div>
      </div>

      {files.length > 0 && <div className="card p-6"><h3 className="text-lg font-bold text-white mb-4">📂 تقدم الملفات</h3><div className="space-y-4">{files.map(file => (<div key={file.id}><div className="flex justify-between text-sm mb-1"><span className="text-zinc-300">{file.name}</span><span className="text-zinc-500">{file.progress}%</span></div><div className="h-2 bg-white/5 rounded-full overflow-hidden"><div className="h-full progress-bar" style={{ width: `${file.progress}%` }} /></div></div>))}</div></div>}
    </div>
  );
}

// ============ SUPPORT VIEW ============
function SupportView() {
  return (
    <div className="space-y-6 animate-fade">
      <h1 className="text-2xl font-bold text-white">🛟 الدعم الفني</h1>
      
      <div className="grid gap-4 md:grid-cols-3">
        {socialLinks.map(link => (
          <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer" className="card p-6 text-center hover:border-violet-500/50">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${link.color} flex items-center justify-center text-3xl mx-auto mb-4`}>{link.icon}</div>
            <h3 className="text-white font-bold mb-1">{link.name}</h3>
            <p className="text-xs text-zinc-500">تواصل معنا عبر {link.name}</p>
          </a>
        ))}
      </div>

      <div className="card p-6">
        <h2 className="text-lg font-bold text-white mb-4">✉️ راسلنا</h2>
        <div className="space-y-4">
          <input placeholder="الاسم" className="input" />
          <input placeholder="البريد الإلكتروني" className="input" />
          <textarea placeholder="رسالتك..." rows={4} className="input resize-none" />
          <button className="btn-primary px-6 py-3 rounded-xl w-full">إرسال</button>
        </div>
      </div>
    </div>
  );
}

// ============ UPLOAD MODAL ============
interface QueuedFile {
  id: string;
  name: string;
  originalFile?: File;
  content: string;
  status: 'pending' | 'reading' | 'processing' | 'done' | 'error';
  error?: string;
  progress: number;
}

function UploadModal({ onClose, onAddFiles }: { onClose: () => void; onAddFiles: (files: StudyFile[]) => void }) {
  const [queue, setQueue] = useState<QueuedFile[]>([]);
  const [category, setCategory] = useState('other');
  const [level, setLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [isProcessing, setIsProcessing] = useState(false);
  const [pasteContent, setPasteContent] = useState('');
  const [pasteName, setPasteName] = useState('');
  const [mode, setMode] = useState<'upload' | 'paste'>('upload');
  const [doneCount, setDoneCount] = useState(0);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Add files to queue
  const addFilesToQueue = (fileList: FileList | File[]) => {
    const newFiles: QueuedFile[] = Array.from(fileList).map(file => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      name: file.name.replace(/\.[^/.]+$/, ''),
      originalFile: file,
      content: '',
      status: 'pending' as const,
      progress: 0,
    }));
    setQueue(prev => [...prev, ...newFiles]);
  };

  const removeFromQueue = (id: string) => {
    setQueue(prev => prev.filter(f => f.id !== id));
  };

  const updateQueueItem = (id: string, updates: Partial<QueuedFile>) => {
    setQueue(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  // Read file content
  const readFileContent = async (qf: QueuedFile): Promise<string> => {
    if (!qf.originalFile) return '';
    const file = qf.originalFile;

    if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
      try {
        const text = await pdfToText(file);
        if (!text.trim()) throw new Error('لا يوجد نص');
        return text;
      } catch {
        throw new Error('فشل قراءة PDF - قد يكون صوراً فقط');
      }
    } else {
      return await file.text();
    }
  };

  // Process all files
  const processAll = async () => {
    setIsProcessing(true);
    setDoneCount(0);
    const results: StudyFile[] = [];

    // If paste mode, add paste content as a queued item
    let itemsToProcess = [...queue];
    if (mode === 'paste' && pasteContent.trim() && pasteName.trim()) {
      itemsToProcess = [{
        id: Date.now().toString(),
        name: pasteName.trim(),
        content: pasteContent.trim(),
        status: 'pending',
        progress: 0,
      }];
      setQueue(itemsToProcess);
    }

    for (let i = 0; i < itemsToProcess.length; i++) {
      const qf = itemsToProcess[i];
      
      // Step 1: Read content
      updateQueueItem(qf.id, { status: 'reading', progress: 30 });
      let content = qf.content;

      if (!content && qf.originalFile) {
        try {
          content = await readFileContent(qf);
        } catch (err: any) {
          updateQueueItem(qf.id, { status: 'error', error: err.message, progress: 0 });
          continue;
        }
      }

      if (!content.trim()) {
        updateQueueItem(qf.id, { status: 'error', error: 'ملف فارغ', progress: 0 });
        continue;
      }

      // Step 2: Process with AI
      updateQueueItem(qf.id, { status: 'processing', progress: 60, content });

      // Small delay to let UI update
      await new Promise(r => setTimeout(r, 100));

      const sections = processFileContent(content);

      const newFile: StudyFile = {
        id: qf.id,
        name: qf.name,
        content,
        category,
        level,
        createdAt: new Date(),
        sections,
        progress: 0,
        totalStudyTime: 0,
        tags: [],
      };

      results.push(newFile);
      updateQueueItem(qf.id, { status: 'done', progress: 100 });
      setDoneCount(prev => prev + 1);
    }

    // Wait a moment to show completion
    await new Promise(r => setTimeout(r, 500));
    
    if (results.length > 0) {
      onAddFiles(results);
    }
    setIsProcessing(false);
  };

  const totalFiles = queue.length || (mode === 'paste' && pasteName && pasteContent ? 1 : 0);
  const canProcess = mode === 'upload' ? queue.length > 0 : (pasteName.trim() && pasteContent.trim());

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade" onClick={() => !isProcessing && onClose()}>
      <div className="card w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white">📂 إضافة ملفات</h2>
            <p className="text-sm text-zinc-500 mt-1">يمكنك رفع عدة ملفات مرة واحدة</p>
          </div>
          <button onClick={() => !isProcessing && onClose()} className="p-2 rounded-lg bg-white/5 text-zinc-400 hover:text-white" disabled={isProcessing}>
            <Icons.X />
          </button>
        </div>

        {/* Mode Toggle */}
        <div className="flex gap-2 mb-6 bg-white/5 rounded-xl p-1">
          <button
            onClick={() => setMode('upload')}
            className={`flex-1 py-3 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              mode === 'upload' ? 'bg-violet-600 text-white' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Icons.Upload /> رفع ملفات
          </button>
          <button
            onClick={() => setMode('paste')}
            className={`flex-1 py-3 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              mode === 'paste' ? 'bg-violet-600 text-white' : 'text-zinc-400 hover:text-white'
            }`}
          >
            ✏️ لصق نص
          </button>
        </div>

        {/* Settings Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Category */}
          <div>
            <label className="block text-sm text-zinc-400 mb-2">التصنيف لجميع الملفات</label>
            <div className="grid grid-cols-4 gap-1.5">
              {categories.slice(1).map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`p-2 rounded-lg text-center transition-all ${
                    category === cat.id ? `bg-gradient-to-br ${cat.color} text-white` : 'bg-white/5 text-zinc-400 hover:bg-white/10'
                  }`}
                >
                  <div className="text-lg">{cat.icon}</div>
                  <div className="text-[10px] mt-0.5">{cat.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Level */}
          <div>
            <label className="block text-sm text-zinc-400 mb-2">المستوى</label>
            <div className="flex gap-2">
              {levels.map(l => (
                <button
                  key={l.id}
                  onClick={() => setLevel(l.id as typeof level)}
                  className={`flex-1 p-2.5 rounded-lg text-center text-sm transition-all ${
                    level === l.id ? `${l.color} text-white` : 'bg-white/5 text-zinc-400 hover:bg-white/10'
                  }`}
                >
                  {l.icon} {l.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* UPLOAD MODE */}
        {mode === 'upload' && (
          <>
            {/* Drop Zone */}
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActive(false);
                if (e.dataTransfer.files.length > 0) addFilesToQueue(e.dataTransfer.files);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all mb-4 ${
                dragActive ? 'border-violet-500 bg-violet-500/10' : 'border-white/10 hover:border-violet-500/30'
              }`}
            >
              <div className="text-4xl mb-3">📁</div>
              <p className="text-white font-medium mb-1">اسحب الملفات هنا أو اضغط للاختيار</p>
              <p className="text-zinc-500 text-sm mb-3">يمكنك اختيار عدة ملفات مرة واحدة</p>
              <div className="flex gap-2 justify-center">
                <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-lg text-xs font-bold">PDF</span>
                <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-lg text-xs font-bold">TXT</span>
                <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-lg text-xs font-bold">MD</span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.txt,.md,.text"
                multiple
                onChange={(e) => e.target.files && e.target.files.length > 0 && addFilesToQueue(e.target.files)}
                className="hidden"
                disabled={isProcessing}
              />
            </div>

            {/* Queue List */}
            {queue.length > 0 && (
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-zinc-400">
                    📋 قائمة الملفات ({queue.length} ملف)
                  </h3>
                  {!isProcessing && (
                    <button
                      onClick={() => setQueue([])}
                      className="text-xs text-red-400 hover:text-red-300"
                    >
                      حذف الكل
                    </button>
                  )}
                </div>

                <div className="max-h-[250px] overflow-y-auto space-y-2 pr-1">
                  {queue.map((qf, i) => (
                    <div
                      key={qf.id}
                      className={`flex items-center gap-3 p-3 rounded-xl border transition-all animate-fade ${
                        qf.status === 'done' ? 'bg-green-500/10 border-green-500/30' :
                        qf.status === 'error' ? 'bg-red-500/10 border-red-500/30' :
                        qf.status === 'reading' || qf.status === 'processing' ? 'bg-violet-500/10 border-violet-500/30' :
                        'bg-white/5 border-white/10'
                      }`}
                      style={{ animationDelay: `${i * 0.03}s` }}
                    >
                      {/* Status Icon */}
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center text-lg flex-shrink-0 bg-white/5">
                        {qf.status === 'done' ? '✅' :
                         qf.status === 'error' ? '❌' :
                         qf.status === 'reading' ? '📖' :
                         qf.status === 'processing' ? '⚙️' :
                         qf.originalFile?.name.endsWith('.pdf') ? '📄' : '📝'}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="text-white text-sm font-medium truncate">{qf.name}</div>
                        <div className="text-xs text-zinc-500">
                          {qf.status === 'pending' && 'جاهز للمعالجة'}
                          {qf.status === 'reading' && '📖 جاري قراءة الملف...'}
                          {qf.status === 'processing' && '⚙️ جاري التحليل بالذكاء الاصطناعي...'}
                          {qf.status === 'done' && '✅ تم بنجاح'}
                          {qf.status === 'error' && <span className="text-red-400">❌ {qf.error}</span>}
                        </div>
                        {(qf.status === 'reading' || qf.status === 'processing') && (
                          <div className="mt-1.5 h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full progress-bar transition-all" style={{ width: `${qf.progress}%` }} />
                          </div>
                        )}
                      </div>

                      {/* Remove Button */}
                      {qf.status === 'pending' && !isProcessing && (
                        <button
                          onClick={() => removeFromQueue(qf.id)}
                          className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10"
                        >
                          <Icons.X />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* PASTE MODE */}
        {mode === 'paste' && (
          <div className="space-y-4 mb-4">
            <div>
              <label className="block text-sm text-zinc-400 mb-2">اسم الملف</label>
              <input
                value={pasteName}
                onChange={e => setPasteName(e.target.value)}
                placeholder="مثال: الفصل الأول - الفيزياء"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-400 mb-2">محتوى النص</label>
              <textarea
                value={pasteContent}
                onChange={e => setPasteContent(e.target.value)}
                placeholder="الصق المحتوى الدراسي هنا..."
                rows={10}
                className="input resize-none"
              />
              <div className="flex justify-between text-xs text-zinc-500 mt-1">
                <span>{pasteContent.length} حرف</span>
                <span>{pasteContent.split(/\s+/).filter(Boolean).length} كلمة</span>
              </div>
            </div>
          </div>
        )}

        {/* Processing Summary */}
        {isProcessing && (
          <div className="card p-4 mb-4 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className="w-5 h-5 border-2 border-violet-400 border-t-transparent rounded-full animate-spin" />
              <span className="text-white font-medium">جاري المعالجة...</span>
            </div>
            <p className="text-sm text-zinc-500">
              تم {doneCount} من {totalFiles} ملفات
            </p>
            <div className="mt-2 h-2 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full progress-bar transition-all" style={{ width: `${totalFiles > 0 ? (doneCount / totalFiles) * 100 : 0}%` }} />
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={processAll}
          disabled={!canProcess || isProcessing}
          className="w-full btn-primary py-4 rounded-xl text-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
        >
          {isProcessing ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              جاري المعالجة... ({doneCount}/{totalFiles})
            </>
          ) : (
            <>
              🚀 {mode === 'upload' 
                ? `تحليل وإضافة ${queue.length > 0 ? queue.length + ' ملف' : ''}` 
                : 'تحليل وإضافة'}
            </>
          )}
        </button>

        {/* Tips */}
        <div className="mt-4 p-3 bg-white/5 rounded-xl flex items-start gap-3">
          <span className="text-lg">💡</span>
          <div className="text-xs text-zinc-500 leading-relaxed">
            <strong className="text-zinc-400">نصائح:</strong><br />
            • يمكنك سحب وإفلات عدة ملفات مرة واحدة<br />
            • اضغط Ctrl/Cmd أثناء الاختيار لتحديد ملفات متعددة<br />
            • الملفات المدعومة: PDF, TXT, MD<br />
            • كل ملف سيتم تحليله وإنشاء ملخصات واختبارات له تلقائياً
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ SEARCH MODAL ============
function SearchModal({ query, setQuery, results, onClose, setView }: { query: string; setQuery: (q: string) => void; results: any; onClose: () => void; setView: (v: ViewMode) => void }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-20 p-4 bg-black/70 backdrop-blur-sm animate-fade" onClick={onClose}>
      <div className="card w-full max-w-2xl max-h-[70vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-white/5 flex items-center gap-3">
          <Icons.Search />
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="ابحث في الملفات والفيديوهات..." className="flex-1 bg-transparent outline-none text-white" autoFocus />
          <button onClick={onClose} className="text-zinc-400 hover:text-white">ESC</button>
        </div>
        <div className="overflow-y-auto max-h-[50vh] p-4">
          {!query && <p className="text-center text-zinc-500 py-8">اكتب للبحث...</p>}
          {query && results.files.length === 0 && results.videos.length === 0 && results.faqs.length === 0 && <p className="text-center text-zinc-500 py-8">لا نتائج لـ "{query}"</p>}
          
          {results.files.length > 0 && <div className="mb-4"><h3 className="text-xs text-zinc-500 mb-2">الملفات</h3>{results.files.slice(0, 3).map((f: StudyFile) => (<button key={f.id} onClick={() => { setView('study'); onClose(); }} className="w-full p-3 rounded-lg bg-white/5 mb-2 text-right hover:bg-white/10"><div className="text-white font-medium">{f.name}</div><div className="text-xs text-zinc-500">{f.sections.length} قسم</div></button>))}</div>}
          
          {results.videos.length > 0 && <div className="mb-4"><h3 className="text-xs text-zinc-500 mb-2">الفيديوهات</h3>{results.videos.slice(0, 3).map((v: Video) => (<a key={v.id} href={v.url} target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-white/5 mb-2 hover:bg-white/10"><div className="text-white font-medium">{v.title}</div><div className="text-xs text-zinc-500">{v.duration}</div></a>))}</div>}
          
          {results.faqs.length > 0 && <div><h3 className="text-xs text-zinc-500 mb-2">الأسئلة الشائعة</h3>{results.faqs.slice(0, 3).map((f: FAQ) => (<button key={f.id} onClick={() => { setView('faq'); onClose(); }} className="w-full p-3 rounded-lg bg-white/5 mb-2 text-right hover:bg-white/10"><div className="text-white font-medium">{f.question}</div></button>))}</div>}
        </div>
      </div>
    </div>
  );
}
