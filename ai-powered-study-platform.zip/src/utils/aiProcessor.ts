import { Section, QuizQuestion, Flashcard } from '../types';

function generateId(): string {
  return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
}

function splitIntoSections(text: string): { title: string; content: string }[] {
  const lines = text.split('\n').filter(l => l.trim());
  const sections: { title: string; content: string }[] = [];
  
  const headerPatterns = [
    /^#{1,3}\s+(.+)/,
    /^(\d+[\.\)]\s+.+)/,
    /^([A-Z\u0600-\u06FF].{5,60})$/,
    /^\*\*(.+)\*\*$/,
    /^[-=]{3,}$/,
  ];

  let currentTitle = '';
  let currentContent: string[] = [];
  let sectionCount = 0;

  for (const line of lines) {
    let isHeader = false;
    for (const pattern of headerPatterns) {
      const match = line.match(pattern);
      if (match && match[1]) {
        if (currentContent.length > 0 || currentTitle) {
          sections.push({
            title: currentTitle || `القسم ${sectionCount + 1}`,
            content: currentContent.join('\n'),
          });
          sectionCount++;
        }
        currentTitle = match[1];
        currentContent = [];
        isHeader = true;
        break;
      }
    }
    if (!isHeader) {
      currentContent.push(line);
    }
  }

  if (currentContent.length > 0 || currentTitle) {
    sections.push({
      title: currentTitle || `القسم ${sectionCount + 1}`,
      content: currentContent.join('\n'),
    });
  }

  // If no sections found or only one, split by paragraphs
  if (sections.length <= 1 && text.length > 300) {
    const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 50);
    if (paragraphs.length > 1) {
      return paragraphs.slice(0, 10).map((p, i) => ({
        title: `الجزء ${i + 1}`,
        content: p.trim(),
      }));
    }
    
    // Split by sentences if still too long
    const sentences = text.split(/[.!?،؟]\s+/);
    const chunks: { title: string; content: string }[] = [];
    let chunk: string[] = [];
    
    for (const sentence of sentences) {
      chunk.push(sentence);
      if (chunk.join('. ').length > 400) {
        chunks.push({ 
          title: `القسم ${chunks.length + 1}`, 
          content: chunk.join('. ') + '.'
        });
        chunk = [];
      }
    }
    if (chunk.length) {
      chunks.push({ title: `القسم ${chunks.length + 1}`, content: chunk.join('. ') });
    }
    return chunks.length > 0 ? chunks : sections;
  }

  return sections.length > 0 ? sections : [{ title: 'المحتوى', content: text }];
}

function generateSummary(content: string): string {
  const sentences = content.split(/[.!?،؟؛]+/).filter(s => s.trim().length > 15);
  if (sentences.length <= 2) return content.trim();
  
  const importantSentences = sentences.slice(0, Math.min(4, sentences.length));
  return importantSentences.join('. ').trim() + '.';
}

function extractKeyPoints(content: string): string[] {
  const sentences = content.split(/[.!?،؟]+/).filter(s => s.trim().length > 10);
  const points: string[] = [];
  
  const keywords = [
    'يجب', 'أهم', 'أساس', 'رئيس', 'مهم', 'ضرور', 'يعني', 'هو', 'هي', 'تعريف',
    'الهدف', 'النتيجة', 'السبب', 'لذلك', 'بالتالي', 'أولاً', 'ثانياً',
    'must', 'important', 'key', 'main', 'essential', 'means', 'result',
    'the', 'is', 'function', 'process', 'method', 'first', 'second'
  ];

  for (const sentence of sentences) {
    const trimmed = sentence.trim();
    if (trimmed.length > 10 && trimmed.length < 200) {
      const hasKeyword = keywords.some(k => trimmed.toLowerCase().includes(k));
      if (hasKeyword || points.length < 4) {
        points.push(trimmed);
      }
    }
    if (points.length >= 6) break;
  }

  return points.length > 0 ? points : sentences.slice(0, 4);
}

function generateExplanation(content: string, title: string): string {
  const isArabic = /[\u0600-\u06FF]/.test(content);
  const firstSentence = content.split(/[.!?،؟]/)[0]?.trim() || title;
  
  if (isArabic) {
    return `📖 **شرح ${title}:**\n\n` +
      `هذا القسم يتحدث عن ${firstSentence}.\n\n` +
      `💡 **الفكرة الأساسية:** ${generateSummary(content)}\n\n` +
      `🎯 **للفهم الأفضل:** حاول ربط هذه المعلومات بما تعرفه مسبقاً، واكتب ملاحظاتك الخاصة.`;
  }
  
  return `📖 **Understanding ${title}:**\n\n` +
    `This section covers ${firstSentence}.\n\n` +
    `💡 **Key Idea:** ${generateSummary(content)}\n\n` +
    `🎯 **For better understanding:** Try to connect this with what you already know.`;
}

function generateQuiz(content: string, title: string): QuizQuestion[] {
  const sentences = content.split(/[.!?،؟]+/).filter(s => s.trim().length > 20);
  const questions: QuizQuestion[] = [];
  const isArabic = /[\u0600-\u06FF]/.test(content);

  if (sentences.length === 0) return [];

  // Generate 3-5 questions
  const numQuestions = Math.min(5, Math.max(2, Math.floor(sentences.length / 2)));

  for (let i = 0; i < numQuestions && i < sentences.length; i++) {
    const sentence = sentences[i].trim();
    
    if (isArabic) {
      questions.push({
        id: generateId(),
        question: `ما المقصود بـ: "${sentence.substring(0, 60)}..."؟`,
        options: [
          sentence.substring(0, 80),
          `هذا لا علاقة له بـ ${title}`,
          'العكس تماماً',
          'لا شيء مما ذكر',
        ],
        correctAnswer: 0,
        explanation: `✅ الإجابة الصحيحة مأخوذة من النص الأصلي.`,
      });
    } else {
      questions.push({
        id: generateId(),
        question: `What does this mean: "${sentence.substring(0, 60)}..."?`,
        options: [
          sentence.substring(0, 80),
          `This is unrelated to ${title}`,
          'The complete opposite',
          'None of the above',
        ],
        correctAnswer: 0,
        explanation: `✅ The correct answer is from the original text.`,
      });
    }
  }

  return questions;
}

function generateFlashcards(content: string, keyPoints: string[]): Flashcard[] {
  const flashcards: Flashcard[] = [];
  const isArabic = /[\u0600-\u06FF]/.test(content);

  for (let i = 0; i < Math.min(keyPoints.length, 5); i++) {
    const point = keyPoints[i];
    flashcards.push({
      id: generateId(),
      front: isArabic ? `ما هو/ما هي: ${point.substring(0, 40)}...؟` : `What is: ${point.substring(0, 40)}...?`,
      back: point,
      mastered: false,
    });
  }

  return flashcards;
}

function determineDifficulty(content: string): 'easy' | 'medium' | 'hard' {
  const words = content.split(/\s+/).length;
  const complexWords = content.match(/\b\w{10,}\b/g)?.length || 0;
  
  if (words < 100 && complexWords < 5) return 'easy';
  if (words > 300 || complexWords > 15) return 'hard';
  return 'medium';
}

export function processFileContent(content: string): Section[] {
  const rawSections = splitIntoSections(content);
  
  return rawSections.map(raw => {
    const keyPoints = extractKeyPoints(raw.content);
    return {
      id: generateId(),
      title: raw.title.replace(/^#+\s*/, '').replace(/^\*\*|\*\*$/g, '').trim(),
      content: raw.content,
      summary: generateSummary(raw.content),
      keyPoints,
      explanation: generateExplanation(raw.content, raw.title),
      quiz: generateQuiz(raw.content, raw.title),
      flashcards: generateFlashcards(raw.content, keyPoints),
      isStudied: false,
      notes: '',
      difficulty: determineDifficulty(raw.content),
    };
  });
}

export function generateAIResponse(question: string, files: { name: string; content: string; sections: { title: string; content: string; summary: string }[] }[]): string {
  const isArabic = /[\u0600-\u06FF]/.test(question);
  const q = question.toLowerCase();

  // Build searchable content
  const allSections = files.flatMap(f => f.sections);

  // Search for relevant content
  const questionWords = question.split(/\s+/).filter(w => w.length > 2);
  const relevantSections = allSections.filter(s => 
    questionWords.some(w => 
      s.content.toLowerCase().includes(w.toLowerCase()) ||
      s.title.toLowerCase().includes(w.toLowerCase())
    )
  );

  if (q.includes('لخص') || q.includes('ملخص') || q.includes('summary')) {
    if (files.length === 0) return isArabic ? '📭 لا توجد ملفات. أضف ملفات أولاً!' : '📭 No files. Add files first!';
    
    let response = isArabic ? '📋 **ملخص ملفاتك:**\n\n' : '📋 **Your Files Summary:**\n\n';
    files.forEach((f, i) => {
      response += `**${i + 1}. ${f.name}**\n`;
      f.sections.slice(0, 3).forEach(s => {
        response += `• ${s.summary.substring(0, 100)}...\n`;
      });
      response += '\n';
    });
    return response;
  }

  if (q.includes('كم') || q.includes('عدد') || q.includes('إحصائ')) {
    const totalSections = files.reduce((a, f) => a + f.sections.length, 0);
    return isArabic
      ? `📊 **الإحصائيات:**\n\n📁 الملفات: ${files.length}\n📑 الأقسام: ${totalSections}`
      : `📊 **Stats:**\n\n📁 Files: ${files.length}\n📑 Sections: ${totalSections}`;
  }

  if (relevantSections.length > 0) {
    let response = isArabic ? '🔍 **وجدت معلومات متعلقة بسؤالك:**\n\n' : '🔍 **Found related information:**\n\n';
    relevantSections.slice(0, 3).forEach((s, i) => {
      response += `**${i + 1}. ${s.title}**\n${s.summary}\n\n`;
    });
    return response;
  }

  return isArabic
    ? `🤔 لم أجد إجابة مباشرة عن "${question}".\n\n💡 **اقتراحات:**\n• أعد صياغة السؤال\n• تأكد أن الموضوع في ملفاتك\n• أضف ملفات جديدة متعلقة`
    : `🤔 Couldn't find a direct answer for "${question}".\n\n💡 **Suggestions:**\n• Rephrase your question\n• Make sure the topic is in your files`;
}
