// IndexedDB Storage for large data
const DB_NAME = 'ArenaStudyDB';
const DB_VERSION = 1;
const STORE_NAME = 'files';

let db: IDBDatabase | null = null;

// Initialize database
export async function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (db) {
      resolve(db);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
}

// Save all files
export async function saveFiles(files: any[]): Promise<void> {
  try {
    const database = await initDB();
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);

    // Clear existing data
    store.clear();

    // Add all files
    for (const file of files) {
      store.put(file);
    }

    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  } catch (error) {
    console.error('Error saving to IndexedDB:', error);
    // Fallback to localStorage with compression
    try {
      const compressed = compressData(files);
      localStorage.setItem('arena_files_backup', compressed);
    } catch (e) {
      console.error('LocalStorage fallback failed:', e);
    }
  }
}

// Load all files
export async function loadFiles(): Promise<any[]> {
  try {
    const database = await initDB();
    const transaction = database.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();

    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const files = request.result || [];
        // Convert date strings back to Date objects
        const processedFiles = files.map((f: any) => ({
          ...f,
          createdAt: new Date(f.createdAt),
          lastStudied: f.lastStudied ? new Date(f.lastStudied) : undefined,
        }));
        resolve(processedFiles);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error loading from IndexedDB:', error);
    // Try localStorage fallback
    try {
      const compressed = localStorage.getItem('arena_files_backup');
      if (compressed) {
        return decompressData(compressed);
      }
    } catch (e) {
      console.error('LocalStorage fallback failed:', e);
    }
    return [];
  }
}

// Add single file
export async function addFile(file: any): Promise<void> {
  const database = await initDB();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  store.put(file);

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

// Delete single file
export async function deleteFile(id: string): Promise<void> {
  const database = await initDB();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  store.delete(id);

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

// Update single file
export async function updateFile(file: any): Promise<void> {
  return addFile(file); // put() updates if exists
}

// Get storage info
export async function getStorageInfo(): Promise<{ used: number; available: number }> {
  if ('storage' in navigator && 'estimate' in navigator.storage) {
    const estimate = await navigator.storage.estimate();
    return {
      used: estimate.usage || 0,
      available: estimate.quota || 0,
    };
  }
  return { used: 0, available: 0 };
}

// Simple compression for localStorage fallback
function compressData(data: any): string {
  const json = JSON.stringify(data);
  // Simple compression: remove extra whitespace and use shorter keys
  return json;
}

function decompressData(compressed: string): any[] {
  try {
    const data = JSON.parse(compressed);
    return data.map((f: any) => ({
      ...f,
      createdAt: new Date(f.createdAt),
      lastStudied: f.lastStudied ? new Date(f.lastStudied) : undefined,
    }));
  } catch {
    return [];
  }
}

// Clear all data
export async function clearAllData(): Promise<void> {
  const database = await initDB();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  store.clear();

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

// Export data for backup
export async function exportData(): Promise<string> {
  const files = await loadFiles();
  return JSON.stringify(files, null, 2);
}

// Import data from backup
export async function importData(jsonString: string): Promise<void> {
  const files = JSON.parse(jsonString);
  await saveFiles(files);
}
